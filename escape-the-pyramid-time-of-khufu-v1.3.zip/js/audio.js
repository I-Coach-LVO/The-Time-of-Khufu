const AudioEngine={
 fxEnabled:true,ctx:null,master:null,musicGain:null,musicTimer:null,step:0,currentRoom:null,musicVolume:.8,
 init(){
  if(this.ctx)return;
  this.ctx=new (window.AudioContext||window.webkitAudioContext)();
  this.master=this.ctx.createGain();this.master.gain.value=.95;this.master.connect(this.ctx.destination);
  this.musicGain=this.ctx.createGain();this.musicGain.gain.value=this.musicVolume*.42;this.musicGain.connect(this.master);
 },
 unlock(){this.init();if(this.ctx.state==='suspended')this.ctx.resume();if(this.currentRoom!==null&&!this.musicTimer&&this.musicVolume>0)this.startMusic(this.currentRoom)},
 tone(freq=440,dur=.12,type='square',vol=.035,when=0,destination=null){
  const isMusic=destination===this.musicGain;if(!isMusic&&!this.fxEnabled)return;
  this.init();const start=this.ctx.currentTime+when,o=this.ctx.createOscillator(),g=this.ctx.createGain();
  o.type=type;o.frequency.setValueAtTime(freq,start);g.gain.setValueAtTime(Math.max(.0001,vol),start);g.gain.exponentialRampToValueAtTime(.0001,start+dur);
  o.connect(g);g.connect(destination||this.master);o.start(start);o.stop(start+dur+.02)
 },
 click(){this.unlock();this.tone(250,.06,'square',.055)},
 ok(){this.unlock();[440,660,880].forEach((f,i)=>this.tone(f,.16,'square',.06,i*.09))},
 bad(){this.unlock();this.tone(120,.28,'sawtooth',.055)},
 rumble(){this.unlock();[70,55,45].forEach((f,i)=>this.tone(f,.45,'sawtooth',.09,i*.1))},
 roomPattern(room){
  const roots=[110,123.47,130.81,146.83,164.81,174.61,196,220,246.94,98];
  const root=roots[Math.max(0,Math.min(9,(room||1)-1))];
  const patterns=[[0,3,7,10,7,3,5,3],[0,5,7,12,10,7,5,3],[0,3,5,7,10,7,5,3],[0,7,5,3,0,3,5,7]];
  return {root,steps:patterns[(room-1)%patterns.length]};
 },
 startMusic(room){
  this.currentRoom=room;if(this.musicTimer){clearInterval(this.musicTimer);this.musicTimer=null}this.step=0;
  if(!this.ctx||this.ctx.state!=='running'||this.musicVolume<=0)return;
  const data=this.roomPattern(room),scale=[1,1.122,1.26,1.335,1.498,1.682,1.888,2,2.245,2.52,2.67,2.996,3.364];
  const tick=()=>{if(this.musicVolume<=0)return;const degree=data.steps[this.step%data.steps.length],freq=data.root*scale[degree];
   this.tone(freq,.19,'square',.11,0,this.musicGain);
   if(this.step%4===0)this.tone(data.root/2,.34,'triangle',.075,0,this.musicGain);
   if(this.step%2===1)this.tone(900,.035,'square',.018,0,this.musicGain);
   this.step++;
  };
  tick();this.musicTimer=setInterval(tick,360);
 },
 stopMusic(){if(this.musicTimer)clearInterval(this.musicTimer);this.musicTimer=null;this.currentRoom=null},
 setMusicVolume(value){
  this.musicVolume=Math.max(0,Math.min(1,Number(value)||0));this.init();
  this.musicGain.gain.cancelScheduledValues(this.ctx.currentTime);
  this.musicGain.gain.setTargetAtTime(this.musicVolume*.42,this.ctx.currentTime,.035);
  if(this.musicVolume===0&&this.musicTimer){clearInterval(this.musicTimer);this.musicTimer=null}
  else if(this.musicVolume>0&&this.currentRoom!==null&&!this.musicTimer)this.startMusic(this.currentRoom);
  return this.musicVolume;
 },
 toggleFX(){this.fxEnabled=!this.fxEnabled;if(this.fxEnabled)this.unlock();return this.fxEnabled}
};
window.addEventListener('pointerdown',()=>AudioEngine.unlock(),{once:true});
window.addEventListener('keydown',()=>AudioEngine.unlock(),{once:true});
