ESCAPE THE PYRAMID — THE TIME OF KHUFU v1.2

Starten:
1. Pak het zipbestand volledig uit.
2. Open index.html in Chrome of Edge.
3. Klik één keer in het spel om browseraudio te activeren.

Nieuw in v1.2:
- Rustige, procedureel gegenereerde 8-bit achtergrondmuziek met een variant per kamer.
- Iedere kamer begint met 2 seconden achtergrond-fade en 1 seconde rust voordat de puzzel verschijnt.
- Kamers 1, 3 en 4 husselen vragen en/of antwoordmogelijkheden.
- Grotere hiërogliefen in kamer 1.
- Duidelijkere instructies in kamer 4.
- Kamer 7 gebruikt twee echte zoek-de-verschillen-afbeeldingen met vijf klikgebieden.
- Kamer 8 maakt bij ieder bezoek een nieuwe Egyptische rekensom.
- Kamer 9 verraadt het antwoord niet meer in de titel.
- De outro toont drie afbeeldingen automatisch: 2 sec fade-in, 5 sec zichtbaar, 2 sec fade-out.

De game werkt offline en gebruikt geen frameworks.

Versie 1.3: muziekvolume 0-100% in de inventarisbalk; FX apart aan/uit; muziek aanzienlijk luider.
